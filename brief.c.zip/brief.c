
#include <stdlib.h>
#include <string.h>

#include <stdlib.h>
#include <string.h>

// include NESLIB header
#include "neslib.h"

// include CC65 NES Header (PPU)
#include <nes.h>

// link the pattern table into CHR ROM
//#link "chr_generic.s"

// BCD arithmetic support
#include "bcd.h"
//#link "bcd.c"

// VRAM update buffer
#include "vrambuf.h"
//#link "vrambuf.c"

/// I'M DOING THE METASPRITE THING HERE

#define TILE 0xd8
#define ATTR 0

const unsigned char metasprite[]={
  	0,	0,	TILE+0,   ATTR,
  	0,	8,	TILE+1,   ATTR,
  	8,	0,	TILE+2,   ATTR,
  	8,	8,	TILE+3,   ATTR,
  128};

/*{pal:"nes",layout:"nes"}*/
const char PALETTE[32] = { 
  0x2D,			// screen color

  0x04,0x10,0x28,0x00,	// background palette 0
  0x1C,0x20,0x2C,0x00,	// background palette 1
  0x00,0x10,0x20,0x00,	// background palette 2
  0x06,0x16,0x26,0x00,   // background palette 3

  0x16,0x35,0x24,0x00,	// sprite palette 0
  0x00,0x37,0x25,0x00,	// sprite palette 1
  0x0D,0x2D,0x3A,0x00,	// sprite palette 2
  0x0D,0x27,0x2A	// sprite palette 3
};

// setup PPU and graphics function.
void setup_graphics() {
  // clear sprites
  oam_clear();
  // set palette colors
  pal_all(PALETTE);
  // Turn on my PPU
  ppu_on_all();
}

#define NUM_ACTORS 16
// Actor positions in x/y
byte actor_x[NUM_ACTORS];
byte actor_y[NUM_ACTORS];

// Deltas per-frame in horizontal and vertical movement
byte actor_dx[NUM_ACTORS];
byte actor_dy[NUM_ACTORS];

// CHANGES THE HORIZONTAL MOVEMENT OF PLAYER 1
void player_move(char joy)
{
  if(joy&PAD_LEFT && actor_x[0]>0)
    actor_dx[0] = -2;
  if(joy&PAD_RIGHT && actor_x[0]>240)
    actor_dx[0] = 2;
  else
    actor_dx[0] = 0;
}



void main()
{
  // Initilization of pad controller
  // and actor data, i and the oam_id
  //char i;
  char oam_id;
  char pad;
  
  
  setup_graphics();
  // draw message  
  vram_adr(NTADR_A(2,2));
  vram_write("Move left and right using \x1e\x1f", 28);
  
  // SET UP LOCATION FOR VULCAN
  actor_x[0] = 120;
  actor_y[0] = 200;
  actor_dx[0] = 0; 
  actor_dy[0] = 0;
  pad = 0; // PLAYER 1 ONLY SCREW TWO PLAYERS!!!!
  // enable rendering
  ppu_on_all();
  ///////////////////////////////
  // PLAY YOUR GAME IDIOT
  
  // infinite loop
  while(1) {
    oam_id = 0;
    pad = pad_poll(0);
    
    if(pad&PAD_LEFT && actor_x[0]>0)
    actor_dx[0] = -2;
    else if(pad&PAD_RIGHT && actor_x[0]<240)
    actor_dx[0] = 2;
    else
    actor_dx[0] = 0;
    
    oam_id = oam_meta_spr(actor_x[0], actor_y[0], oam_id, metasprite);
    actor_x[0] += actor_dx[0];
    actor_y[0] += actor_dy[0];
    
    ppu_wait_frame();
  }
}


